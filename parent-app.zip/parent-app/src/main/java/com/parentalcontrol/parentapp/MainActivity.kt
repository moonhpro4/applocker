package com.parentalcontrol.parentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.parentalcontrol.parentapp.databinding.ActivityMainBinding
import com.parentalcontrol.parentapp.services.PairingManager

class MainActivity : AppCompatActivity(), PairingManager.PairingCallback {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var pairingManager: PairingManager
    private var currentDeviceIp: String = ""
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        pairingManager = PairingManager(this)
        
        setupUI()
        checkExistingPairing()
    }
    
    private fun setupUI() {
        binding.btnPairDevice.setOnClickListener {
            val ipAddress = binding.etDeviceIp.text.toString().trim()
            if (ipAddress.isEmpty()) {
                Toast.makeText(this, "Please enter device IP address", Toast.LENGTH_SHORT).show()
                return@setClickListener
            }
            
            currentDeviceIp = ipAddress
            startPairingProcess(ipAddress)
        }
        
        binding.btnEnterCode.setOnClickListener {
            val code = binding.etPairingCode.text.toString().trim()
            if (code.isEmpty()) {
                Toast.makeText(this, "Please enter pairing code", Toast.LENGTH_SHORT).show()
                return@setClickListener
            }
            
            pairingManager.verifyPairingCode(code)
        }
        
        binding.btnManageDevice.setOnClickListener {
            if (pairingManager.isDevicePaired()) {
                val intent = Intent(this, DeviceManagementActivity::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "No device paired", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun checkExistingPairing() {
        if (pairingManager.isDevicePaired()) {
            binding.tvStatus.text = "Device Paired"
            binding.btnManageDevice.isEnabled = true
            binding.pairingLayout.visibility = android.view.View.GONE
            binding.managementLayout.visibility = android.view.View.VISIBLE
        }
    }
    
    private fun startPairingProcess(ipAddress: String) {
        binding.tvStatus.text = "Connecting to device..."
        binding.progressBar.visibility = android.view.View.VISIBLE
        
        pairingManager.startPairingProcess(ipAddress, this)
    }
    
    override fun onPairingCodeReceived(code: String) {
        runOnUiThread {
            binding.tvStatus.text = "Enter pairing code: $code"
            binding.progressBar.visibility = android.view.View.GONE
            binding.codeEntryLayout.visibility = android.view.View.VISIBLE
            binding.etPairingCode.setText(code)
        }
    }
    
    override fun onPairingSuccess(deviceId: String) {
        runOnUiThread {
            binding.tvStatus.text = "Pairing successful!"
            binding.codeEntryLayout.visibility = android.view.View.GONE
            binding.managementLayout.visibility = android.view.View.VISIBLE
            binding.btnManageDevice.isEnabled = true
            
            Toast.makeText(this, "Device paired successfully", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onPairingFailed(reason: String) {
        runOnUiThread {
            binding.tvStatus.text = "Pairing failed: ${if (reason == "invalid_code") "Invalid code" else "Code expired"}"
            binding.progressBar.visibility = android.view.View.GONE
            binding.codeEntryLayout.visibility = android.view.View.GONE
            
            Toast.makeText(this, "Pairing failed", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onConnectionError(error: String) {
        runOnUiThread {
            binding.tvStatus.text = "Connection error: $error"
            binding.progressBar.visibility = android.view.View.GONE
            
            Toast.makeText(this, "Connection failed: $error", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        pairingManager.disconnect()
    }
}
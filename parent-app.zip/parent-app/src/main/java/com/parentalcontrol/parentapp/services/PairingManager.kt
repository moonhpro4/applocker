package com.parentalcontrol.parentapp.services

import android.content.Context
import android.content.Intent
import android.util.Log
import com.parentalcontrol.parentapp.utils.NetworkUtils
import com.parentalcontrol.parentapp.utils.EncryptionUtils
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI
import java.util.concurrent.TimeUnit

class PairingManager(private val context: Context) {
    
    companion object {
        private const val TAG = "PairingManager"
        private const val WEBSOCKET_TIMEOUT = 10000L
    }
    
    private var webSocketClient: WebSocketClient? = null
    private var pairingCallback: PairingCallback? = null
    private var currentPairingCode: String? = null
    
    interface PairingCallback {
        fun onPairingCodeReceived(code: String)
        fun onPairingSuccess(deviceId: String)
        fun onPairingFailed(reason: String)
        fun onConnectionError(error: String)
    }
    
    fun startPairingProcess(deviceIp: String, callback: PairingCallback) {
        this.pairingCallback = callback
        
        if (!NetworkUtils.isDeviceOnSameNetwork(context, deviceIp)) {
            callback.onConnectionError("Devices are not on the same network")
            return
        }
        
        connectToWebSocket(deviceIp, callback)
    }
    
    private fun connectToWebSocket(deviceIp: String, callback: PairingCallback) {
        val uri = URI("ws://$deviceIp:8080/pairing")
        
        webSocketClient = object : WebSocketClient(uri) {
            override fun onOpen(handshakedata: ServerHandshake?) {
                Log.d(TAG, "WebSocket connection opened")
                requestPairingCode()
            }
            
            override fun onMessage(message: String?) {
                message?.let { handleWebSocketMessage(it) }
            }
            
            override fun onClose(code: Int, reason: String?, remote: Boolean) {
                Log.d(TAG, "WebSocket connection closed: $reason")
                pairingCallback?.onConnectionError("Connection closed: $reason")
            }
            
            override fun onError(ex: Exception?) {
                Log.e(TAG, "WebSocket error: ${ex?.message}")
                pairingCallback?.onConnectionError("Connection error: ${ex?.message}")
            }
        }
        
        try {
            webSocketClient?.connect()
        } catch (e: Exception) {
            callback.onConnectionError("Failed to connect: ${e.message}")
        }
    }
    
    private fun handleWebSocketMessage(message: String) {
        when {
            message.startsWith("PAIRING_CODE:") -> {
                val code = message.substringAfter("PAIRING_CODE:")
                currentPairingCode = code
                pairingCallback?.onPairingCodeReceived(code)
            }
            message.startsWith("PAIRING_SUCCESS:") -> {
                val deviceId = message.substringAfter("PAIRING_SUCCESS:")
                savePairedDevice(deviceId)
                pairingCallback?.onPairingSuccess(deviceId)
            }
            message.startsWith("PAIRING_FAILED:") -> {
                val reason = message.substringAfter("PAIRING_FAILED:")
                pairingCallback?.onPairingFailed(reason)
            }
        }
    }
    
    private fun requestPairingCode() {
        webSocketClient?.send("REQUEST_PAIRING_CODE")
    }
    
    fun verifyPairingCode(code: String) {
        webSocketClient?.send("VERIFY_CODE:$code")
    }
    
    private fun savePairedDevice(deviceId: String) {
        val prefs = context.getSharedPreferences("pairing_prefs", Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putBoolean("is_paired", true)
            putString("paired_device_id", deviceId)
            putLong("paired_timestamp", System.currentTimeMillis())
            apply()
        }
    }
    
    fun getPairedDeviceId(): String? {
        val prefs = context.getSharedPreferences("pairing_prefs", Context.MODE_PRIVATE)
        return prefs.getString("paired_device_id", null)
    }
    
    fun isDevicePaired(): Boolean {
        val prefs = context.getSharedPreferences("pairing_prefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("is_paired", false)
    }
    
    fun disconnect() {
        webSocketClient?.close()
        webSocketClient = null
        pairingCallback = null
    }
}